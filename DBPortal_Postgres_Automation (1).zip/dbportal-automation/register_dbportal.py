#!/usr/bin/env python3
"""Read PostgreSQL inventory; preview/apply DBPortal registration via SQL Server."""
import argparse
import copy
import json
import os
import sys
from pathlib import Path

class RegistrationError(ValueError):
    pass

def secret(name, required=True):
    value=os.environ.get(name)
    if required and (value is None or value.startswith('<') or 'REPLACE' in value):
        raise RegistrationError(f'Set environment variable {name}; placeholder values are not accepted.')
    return value

def required_int(value, field):
    if isinstance(value,bool) or not isinstance(value,int):
        raise RegistrationError(f'{field} must be an integer; replace its placeholder.')
    return value

def validate_payload(p, apply=False):
    required={'host':{'hostname':250,'IPAddress':20,'Used_By':4},
              'instance':{'instanceName':50}}
    for section,fields in required.items():
        for field,size in fields.items():
            v=p[section].get(field)
            if not isinstance(v,str) or not v.strip() or len(v)>size or '<' in v or 'REPLACE' in v:
                raise RegistrationError(f'Invalid {section}.{field}; supply a value of at most {size} characters.')
    for f in ['OS_Id','OS_Version_Id','OS_Pak_Id','Platform_Type','status_key']:
        required_int(p['host'].get(f),'host.'+f)
    for f in ['DB_Type_Id','DB_Version_Id','DB_Pak_Id','Status_Key','Env_key','Port']:
        required_int(p['instance'].get(f),'instance.'+f)
    if not 1<=p['instance']['Port']<=65535:
        raise RegistrationError('Port must be between 1 and 65535.')
    names=set()
    if not isinstance(p.get('databases'),list) or not p['databases']:
        raise RegistrationError('At least one database must be discovered.')
    for d in p['databases']:
        name=d.get('Dbname')
        if not isinstance(name,str) or not name or len(name)>256 or name in names:
            raise RegistrationError('Missing, duplicate, or oversized database name.')
        names.add(name)
        for f in ['Env_Key','Status_Key']:
            required_int(d.get(f),name+'.'+f)
        if d.get('CName') is not None and (not isinstance(d['CName'],str) or len(d['CName'])>50):
            raise RegistrationError(name+'.CName exceeds 50 characters or is not text.')
        if d.get('Archival_key') is not None:
            required_int(d['Archival_key'],name+'.Archival_key')
        seen=set()
        if not isinstance(d.get('applications'),list) or not d['applications']:
            raise RegistrationError('Application mapping required for '+name)
        for a in d['applications']:
            required_int(a.get('Contact_Key'),name+'.Contact_Key')
            required_int(a.get('AppTypeID'),name+'.AppTypeID')
            if a.get('BAI_ID') is not None:
                required_int(a['BAI_ID'],name+'.BAI_ID')
            if not isinstance(a.get('AppName'),str) or not a['AppName'].strip() or len(a['AppName'])>300 or '<' in a['AppName']:
                raise RegistrationError('Invalid AppName for '+name)
            if a.get('BAI_Env_Key') is not None and (not isinstance(a['BAI_Env_Key'],str) or len(a['BAI_Env_Key'])>25):
                raise RegistrationError('Invalid BAI_Env_Key for '+name)
            key=(a['AppTypeID'],a['BAI_ID'],a.get('BAI_Env_Key') or '') if a.get('BAI_ID') is not None else (a['AppTypeID'],a['AppName'])
            if key in seen:
                raise RegistrationError('Duplicate application mapping for '+name)
            seen.add(key)

def discover(config):
    import psycopg
    pg=config['postgres']
    kwargs={k:pg[k] for k in ['host','port','dbname','sslmode','sslrootcert'] if k in pg}
    kwargs.update(user=secret(pg['username_env']),password=secret(pg['password_env']),
                  connect_timeout=10,application_name='dbportal_inventory')
    with psycopg.connect(**kwargs) as conn:
        with conn.cursor() as cur:
            cur.execute('SET TRANSACTION READ ONLY')
            cur.execute("SELECT current_setting('server_version'), current_setting('port')::int, pg_is_in_recovery()")
            version,port,recovery=cur.fetchone()
            cur.execute('SELECT datname, datistemplate FROM pg_database ORDER BY datname')
            databases=cur.fetchall()
    # Postgres DBVersion uses short canonical labels even for EDB installations.
    first=version.split()[0]
    if not first.replace('.','').isdigit():
        raise RegistrationError('Unrecognized server_version; supply/confirm canonical portal version.')
    h=copy.deepcopy(config['host'])
    h['hostname']=h['hostname'].strip().lower()
    i=copy.deepcopy(config['instance'])
    i['Port']=port
    i.pop('DB_Version_Id',None)
    mappings=config['database_mappings']
    result=[]
    for name,is_template in databases:
        if is_template and not config.get('include_templates',True):
            continue
        if name in config.get('exclude_databases',[]):
            continue
        mapping=mappings.get(name,mappings.get('*'))
        if mapping is None:
            raise RegistrationError('No application mapping for database '+name)
        apps=copy.deepcopy(mapping['applications'])
        for a in apps:
            a.setdefault('BAI_ID',None)
            a.setdefault('BAI_Env_Key',None)
        result.append({'Dbname':name,'Env_Key':i['Env_key'],
                       'Status_Key':i['Status_Key'],'Archival_key':mapping.get('Archival_key',2),
                       'CName':mapping.get('CName'), 'applications':apps})
    return {'host':h,'instance':i,'databases':result}, {'server_version':version,
        'canonical_version':'PostgreSQL '+first,'in_recovery':recovery}

def sql_connection(config):
    import pyodbc
    value=secret(config['sqlserver']['connection_string_env'])
    return pyodbc.connect(value,autocommit=True,timeout=15)

def resolve_version(conn,payload,label):
    cur=conn.cursor()
    rows=cur.execute('SELECT DB_Version_Id FROM dbo.DBVersion WHERE DB_Version_Nm = ?',label).fetchall()
    if len(rows)!=1:
        raise RegistrationError('Canonical DBVersion label must match exactly one row: '+label)
    payload['instance']['DB_Version_Id']=int(rows[0][0])

def portal_credentials(config,payload):
    c=config['portal_credentials']
    allow=bool(c.get('allow_empty',False))
    payload['allow_empty_portal_credentials']=int(allow)
    if allow:
        payload['instance'].update(Username='',Password='',IsEncrypted=0)
    else:
        # Optional for existing instances; the procedure requires them when creating one.
        payload['instance'].update(Username=secret(c['username_env'],False),
                                  Password=secret(c['password_env'],False),
                                  IsEncrypted=c.get('is_encrypted'))

def redacted(p):
    value=copy.deepcopy(p)
    for f in ['Username','Password']:
        if f in value['instance']:
            value['instance'][f]='[REDACTED]'
    return value

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True)
    modes=parser.add_mutually_exclusive_group()
    modes.add_argument('--collect-only',action='store_true',help='Discover and show metadata; no SQL Server connection')
    modes.add_argument('--preview',action='store_true',help='Default: compare with SQL Server without table writes')
    modes.add_argument('--apply',action='store_true',help='Commit registration changes')
    args=parser.parse_args(argv)
    config=json.loads(Path(args.config).read_text())
    payload,observed=discover(config)
    if args.collect_only:
        print(json.dumps({'observed':observed,'registration':payload},indent=2))
        return 0
    with sql_connection(config) as conn:
        resolve_version(conn,payload,config.get('canonical_version_override') or observed['canonical_version'])
        validate_payload(payload,args.apply)
        portal_credentials(config,payload)
        cur=conn.cursor()
        cur.execute('EXEC dbo.usp_RegisterPostgresInventory @Payload=?, @Preview=?',
                    json.dumps(payload),int(not args.apply))
        results=[]
        while True:
            if cur.description:
                fields=[d[0] for d in cur.description]
                results.extend(dict(zip(fields,row)) for row in cur.fetchall())
            if not cur.nextset():
                break
    print(json.dumps({'mode':'apply' if args.apply else 'preview','observed':observed,
                      'registration':redacted(payload),'results':results},indent=2,default=str))
    return 0

if __name__=='__main__':
    try:
        sys.exit(main())
    except RegistrationError as exc:
        print('Registration validation failed: '+str(exc),file=sys.stderr)
        sys.exit(2)
    except Exception as exc:
        # Do not echo driver errors/connection strings/payloads that could contain credentials.
        print('Registration failed ('+type(exc).__name__+'). Check connectivity, permissions, TLS, and procedure validation using secure DBA diagnostics.',file=sys.stderr)
        sys.exit(1)

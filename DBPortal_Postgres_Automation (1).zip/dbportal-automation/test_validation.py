import copy
import unittest
from register_dbportal import validate_payload,redacted,RegistrationError

class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.p={'host':{'hostname':'pg.example.internal','IPAddress':'192.0.2.1','Used_By':'FCB','OS_Id':2,'OS_Version_Id':51,'OS_Pak_Id':3,'Platform_Type':1,'status_key':1},
                'instance':{'instanceName':'enterprisedb','DB_Type_Id':61,'DB_Version_Id':535,'DB_Pak_Id':3,'Status_Key':1,'Env_key':2,'Port':7432},
                'databases':[{'Dbname':'test','Env_Key':2,'Status_Key':1,'CName':None,'applications':[{'AppName':'Test','AppTypeID':1,'Contact_Key':123,'BAI_ID':None}]}]}
    def test_valid(self):
        validate_payload(self.p)
    def test_contact_placeholder_rejected(self):
        self.p['databases'][0]['applications'][0]['Contact_Key']='<CONTACT_KEY>'
        with self.assertRaises(RegistrationError): validate_payload(self.p)
    def test_duplicate_database_rejected(self):
        self.p['databases'].append(copy.deepcopy(self.p['databases'][0]))
        with self.assertRaises(RegistrationError): validate_payload(self.p)
    def test_case_distinct_database_allowed(self):
        d=copy.deepcopy(self.p['databases'][0]); d['Dbname']='Test'; self.p['databases'].append(d)
        validate_payload(self.p)
    def test_duplicate_application_rejected(self):
        a=self.p['databases'][0]['applications'];a.append(copy.deepcopy(a[0]))
        with self.assertRaises(RegistrationError): validate_payload(self.p)
    def test_long_cname_rejected(self):
        self.p['databases'][0]['CName']='x'*51
        with self.assertRaises(RegistrationError): validate_payload(self.p)
    def test_redaction_does_not_mutate_input(self):
        self.p['instance'].update(Username='testuser',Password='secret')
        r=redacted(self.p)
        self.assertEqual(r['instance']['Password'],'[REDACTED]')
        self.assertEqual(self.p['instance']['Password'],'secret')

if __name__=='__main__': unittest.main()

USE [dbstatus];
SELECT name,compatibility_level FROM sys.databases WHERE name=DB_NAME();
SELECT hostname,Used_By,COUNT(*) AS DuplicateCount FROM dbo.HostInfo GROUP BY hostname,Used_By HAVING COUNT(*)>1;
SELECT hostId,Port,COUNT(*) AS DuplicateCount FROM dbo.InstanceInfo GROUP BY hostId,Port HAVING COUNT(*)>1;
SELECT instanceId,Dbname COLLATE Latin1_General_100_BIN2 AS Dbname,COUNT(*) AS DuplicateCount
FROM dbo.DBinfo GROUP BY instanceId,Dbname COLLATE Latin1_General_100_BIN2 HAVING COUNT(*)>1;
SELECT d.dbid,d.hostid,d.instanceId,i.hostId AS InstanceHost
FROM dbo.DBinfo d JOIN dbo.InstanceInfo i ON i.instanceId=d.instanceId WHERE d.hostid<>i.hostId;
SELECT DB_Version_Nm,COUNT(*) AS DuplicateCount FROM dbo.DBVersion GROUP BY DB_Version_Nm HAVING COUNT(*)>1;
SELECT OBJECT_NAME(parent_id) AS TableName,name,is_disabled FROM sys.triggers
WHERE parent_id IN (OBJECT_ID('dbo.HostInfo'),OBJECT_ID('dbo.InstanceInfo'),OBJECT_ID('dbo.DBinfo'),OBJECT_ID('dbo.AppInfo'));
SELECT OBJECT_NAME(parent_object_id) AS TableName,name,is_disabled,is_not_trusted FROM sys.foreign_keys
WHERE parent_object_id IN (OBJECT_ID('dbo.HostInfo'),OBJECT_ID('dbo.InstanceInfo'),OBJECT_ID('dbo.DBinfo'),OBJECT_ID('dbo.AppInfo'));
SELECT OBJECT_NAME(object_id) AS TableName,name,is_unique,is_primary_key FROM sys.indexes
WHERE object_id IN (OBJECT_ID('dbo.HostInfo'),OBJECT_ID('dbo.InstanceInfo'),OBJECT_ID('dbo.DBinfo'),OBJECT_ID('dbo.AppInfo'));

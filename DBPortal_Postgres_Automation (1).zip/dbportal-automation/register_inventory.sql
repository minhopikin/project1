USE [dbstatus];
GO
CREATE OR ALTER PROCEDURE dbo.usp_RegisterPostgresInventory
    @Payload nvarchar(max), @Preview bit = 1
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @@TRANCOUNT <> 0 THROW 51000, 'Call outside an existing transaction.', 1;
 IF ISJSON(@Payload) <> 1 THROW 51000, 'Invalid JSON payload.', 1;
 DECLARE @HostID int, @InstanceID int, @DBID int, @AppID int,
         @Count int, @Action varchar(20), @LockResult int;
 DECLARE @Results TABLE (Sequence int IDENTITY, Entity varchar(20), Name nvarchar(300),
                         Action varchar(20), RecordID int);
 DECLARE @hostname varchar(250)=JSON_VALUE(@Payload,'$.host.hostname'),
         @source varchar(4)=JSON_VALUE(@Payload,'$.host.Used_By');
 IF NULLIF(LTRIM(RTRIM(@hostname)),'') IS NULL OR NULLIF(@source,'') IS NULL
   THROW 51000, 'Hostname and Used_By are required.', 1;
 IF LOWER(@hostname) LIKE '%replace%' OR @hostname LIKE '%<%'
   THROW 51000, 'Replace hostname placeholder.', 1;
 IF JSON_QUERY(@Payload,'$.databases') IS NULL THROW 51000, 'databases array is required.', 1;
 IF LEN(JSON_VALUE(@Payload,'$.host.hostname'))>250 OR LEN(JSON_VALUE(@Payload,'$.host.Used_By'))>4
   THROW 51000, 'Hostname or source exceeds column length.', 1;
 IF EXISTS (SELECT JSON_VALUE(value,'$.Dbname') COLLATE Latin1_General_100_BIN2
            FROM OPENJSON(@Payload,'$.databases') GROUP BY JSON_VALUE(value,'$.Dbname') COLLATE Latin1_General_100_BIN2 HAVING COUNT(*)>1)
   THROW 51000, 'Duplicate database names in payload.', 1;
 BEGIN TRY
  BEGIN TRANSACTION;
  -- Serialize this procedure's registrations. Other DBPortal writers do not take this lock.
  EXEC @LockResult=sys.sp_getapplock @Resource=N'DBPortal.Inventory.Registration',
       @LockMode='Exclusive', @LockOwner='Transaction', @LockTimeout=15000;
  IF @LockResult < 0 THROW 51000, 'Could not acquire registration lock.', 1;
  IF LEN(JSON_VALUE(JSON_QUERY(@Payload,'$.host'),'$.IPAddress'))>20 THROW 51000, 'Field too long: h_IPAddress', 1;
  DECLARE @h_IPAddress varchar(20),
          @h_DASD bit,
          @h_BootDASD bit,
          @h_OS_Id int,
          @h_OS_Version_Id int,
          @h_OS_Pak_Id int,
          @h_ClusterID int,
          @h_status_key int,
          @h_Platform_Type int;
  SELECT @h_IPAddress=[IPAddress], @h_DASD=[DASD], @h_BootDASD=[BootDASD], @h_OS_Id=[OS_Id], @h_OS_Version_Id=[OS_Version_Id], @h_OS_Pak_Id=[OS_Pak_Id], @h_ClusterID=[ClusterID], @h_status_key=[status_key], @h_Platform_Type=[Platform_Type]
  FROM OPENJSON(JSON_QUERY(@Payload,'$.host')) WITH (
    [IPAddress] varchar(20) '$.IPAddress',
    [DASD] bit '$.DASD',
    [BootDASD] bit '$.BootDASD',
    [OS_Id] int '$.OS_Id',
    [OS_Version_Id] int '$.OS_Version_Id',
    [OS_Pak_Id] int '$.OS_Pak_Id',
    [ClusterID] int '$.ClusterID',
    [status_key] int '$.status_key',
    [Platform_Type] int '$.Platform_Type');
  IF @h_IPAddress IS NULL THROW 51000, 'Required field: h_IPAddress', 1;
  IF @h_DASD IS NULL THROW 51000, 'Required field: h_DASD', 1;
  IF @h_BootDASD IS NULL THROW 51000, 'Required field: h_BootDASD', 1;
  IF @h_OS_Id IS NULL THROW 51000, 'Required field: h_OS_Id', 1;
  IF @h_OS_Version_Id IS NULL THROW 51000, 'Required field: h_OS_Version_Id', 1;
  IF @h_OS_Pak_Id IS NULL THROW 51000, 'Required field: h_OS_Pak_Id', 1;
  IF @h_Platform_Type IS NULL THROW 51000, 'Required field: h_Platform_Type', 1;
  IF @h_OS_Id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[OS] WHERE [OS_Id]=@h_OS_Id)
    THROW 51000, 'Invalid lookup: h_OS_Id', 1;
  IF @h_OS_Version_Id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[OSVersion] WHERE [OS_Version_Id]=@h_OS_Version_Id)
    THROW 51000, 'Invalid lookup: h_OS_Version_Id', 1;
  IF @h_OS_Pak_Id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[OSPak] WHERE [OS_Pak_Id]=@h_OS_Pak_Id)
    THROW 51000, 'Invalid lookup: h_OS_Pak_Id', 1;
  IF @h_Platform_Type IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[Platform] WHERE [Platform_Type]=@h_Platform_Type)
    THROW 51000, 'Invalid lookup: h_Platform_Type', 1;
  IF @h_status_key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[StatusInfo] WHERE [Status_Key]=@h_status_key)
    THROW 51000, 'Invalid lookup: h_status_key', 1;
  SET @HostID=NULL;
  SELECT @Count=COUNT(*), @HostID=MIN([HostID]) FROM dbo.[HostInfo] WITH (UPDLOCK,HOLDLOCK) WHERE hostname=@hostname AND Used_By=@source;
  IF @Count>1 THROW 51000, 'Ambiguous existing Host; resolve duplicates first.', 1;
  SET @Action='Unchanged';
  IF @Count=0
  BEGIN
   SET @Action='Create';
   IF @Preview=0
   BEGIN

    INSERT dbo.[HostInfo] ([hostname],[Used_By],[IPAddress],[DASD],[BootDASD],[OS_Id],[OS_Version_Id],[OS_Pak_Id],[ClusterID],[status_key],[Platform_Type]) VALUES (@hostname,@source,@h_IPAddress,@h_DASD,@h_BootDASD,@h_OS_Id,@h_OS_Version_Id,@h_OS_Pak_Id,@h_ClusterID,@h_status_key,@h_Platform_Type);
    SET @HostID=CONVERT(int,SCOPE_IDENTITY());
   END
   ELSE SET @HostID=-1;
  END
  ELSE IF EXISTS (SELECT @hostname,@source,@h_IPAddress,@h_DASD,@h_BootDASD,@h_OS_Id,@h_OS_Version_Id,@h_OS_Pak_Id,@h_ClusterID,@h_status_key,@h_Platform_Type EXCEPT SELECT [hostname],[Used_By],[IPAddress],[DASD],[BootDASD],[OS_Id],[OS_Version_Id],[OS_Pak_Id],[ClusterID],[status_key],[Platform_Type] FROM dbo.[HostInfo] WHERE [HostID]=@HostID)
  BEGIN
   SET @Action='Update';
   IF @Preview=0 UPDATE dbo.[HostInfo] SET [hostname]=@hostname,[Used_By]=@source,[IPAddress]=@h_IPAddress,[DASD]=@h_DASD,[BootDASD]=@h_BootDASD,[OS_Id]=@h_OS_Id,[OS_Version_Id]=@h_OS_Version_Id,[OS_Pak_Id]=@h_OS_Pak_Id,[ClusterID]=@h_ClusterID,[status_key]=@h_status_key,[Platform_Type]=@h_Platform_Type WHERE [HostID]=@HostID;
  END
  INSERT @Results (Entity,Name,Action,RecordID) VALUES ('Host',@hostname,@Action,NULLIF(@HostID,-1));
  IF LEN(JSON_VALUE(JSON_QUERY(@Payload,'$.instance'),'$.instanceName'))>50 THROW 51000, 'Field too long: i_instanceName', 1;
  DECLARE @i_instanceName varchar(50),
          @i_DB_Type_Id int,
          @i_Port int,
          @i_DB_Version_Id int,
          @i_DB_Pak_Id int,
          @i_Status_Key int,
          @i_Env_key int;
  SELECT @i_instanceName=[instanceName], @i_DB_Type_Id=[DB_Type_Id], @i_Port=[Port], @i_DB_Version_Id=[DB_Version_Id], @i_DB_Pak_Id=[DB_Pak_Id], @i_Status_Key=[Status_Key], @i_Env_key=[Env_key]
  FROM OPENJSON(JSON_QUERY(@Payload,'$.instance')) WITH (
    [instanceName] varchar(50) '$.instanceName',
    [DB_Type_Id] int '$.DB_Type_Id',
    [Port] int '$.Port',
    [DB_Version_Id] int '$.DB_Version_Id',
    [DB_Pak_Id] int '$.DB_Pak_Id',
    [Status_Key] int '$.Status_Key',
    [Env_key] int '$.Env_key');
  IF @i_instanceName IS NULL THROW 51000, 'Required field: i_instanceName', 1;
  IF @i_DB_Type_Id IS NULL THROW 51000, 'Required field: i_DB_Type_Id', 1;
  IF @i_Port IS NULL THROW 51000, 'Required field: i_Port', 1;
  IF @i_DB_Version_Id IS NULL THROW 51000, 'Required field: i_DB_Version_Id', 1;
  IF @i_DB_Pak_Id IS NULL THROW 51000, 'Required field: i_DB_Pak_Id', 1;
  IF @i_Status_Key IS NULL THROW 51000, 'Required field: i_Status_Key', 1;
  IF @i_Env_key IS NULL THROW 51000, 'Required field: i_Env_key', 1;
  IF @i_DB_Type_Id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[DBType] WHERE [DB_Type_Id]=@i_DB_Type_Id)
    THROW 51000, 'Invalid lookup: i_DB_Type_Id', 1;
  IF @i_DB_Version_Id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[DBVersion] WHERE [DB_Version_Id]=@i_DB_Version_Id)
    THROW 51000, 'Invalid lookup: i_DB_Version_Id', 1;
  IF @i_DB_Pak_Id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[DBPak] WHERE [DB_Pak_Id]=@i_DB_Pak_Id)
    THROW 51000, 'Invalid lookup: i_DB_Pak_Id', 1;
  IF @i_Status_Key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[StatusInfo] WHERE [Status_Key]=@i_Status_Key)
    THROW 51000, 'Invalid lookup: i_Status_Key', 1;
  IF @i_Env_key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[EnvInfo] WHERE [Env_Key]=@i_Env_key)
    THROW 51000, 'Invalid lookup: i_Env_key', 1;
  IF @i_DB_Type_Id NOT IN (61,64) THROW 51000, 'Only the supplied PostgreSQL type IDs 61 and 64 are supported.', 1;
  IF @i_Port NOT BETWEEN 1 AND 65535 THROW 51000, 'Invalid PostgreSQL port.', 1;
  DECLARE @User nvarchar(max)=JSON_VALUE(@Payload,'$.instance.Username'), @Pass nvarchar(max)=JSON_VALUE(@Payload,'$.instance.Password'), @Encrypted bit=TRY_CONVERT(bit,JSON_VALUE(@Payload,'$.instance.IsEncrypted')), @AllowEmpty bit=ISNULL(TRY_CONVERT(bit,JSON_VALUE(@Payload,'$.allow_empty_portal_credentials')),0);
  SET @InstanceID=NULL;
  SELECT @Count=COUNT(*), @InstanceID=MIN([instanceId]) FROM dbo.[InstanceInfo] WITH (UPDLOCK,HOLDLOCK) WHERE hostId=@HostID AND Port=@i_Port;
  IF @Count>1 THROW 51000, 'Ambiguous existing Instance; resolve duplicates first.', 1;
  SET @Action='Unchanged';
  IF @Count=0
  BEGIN
   SET @Action='Create';
   IF @Preview=0
   BEGIN
    IF @User IS NULL OR @Pass IS NULL THROW 51000, 'New instance requires portal credential values.', 1;
    IF LEN(@User)>20 OR LEN(@Pass)>20 THROW 51000, 'Portal credentials exceed varchar(20); do not truncate.', 1;
    IF @User LIKE '%REPLACE%' OR @Pass LIKE '%REPLACE%' OR @User LIKE '%<%' OR @Pass LIKE '%<%'
      THROW 51000, 'Replace portal credential placeholders.', 1;
    IF @AllowEmpty=0 AND (NULLIF(@User,'') IS NULL OR NULLIF(@Pass,'') IS NULL)
      THROW 51000, 'Empty portal credentials require an explicitly approved policy flag.', 1;
    INSERT dbo.[InstanceInfo] ([hostId],[Used_By],[instanceName],[DB_Type_Id],[Port],[DB_Version_Id],[DB_Pak_Id],[Status_Key],[Env_key],[Username],[Password],[IsEncrypted]) VALUES (@HostID,@source,@i_instanceName,@i_DB_Type_Id,@i_Port,@i_DB_Version_Id,@i_DB_Pak_Id,@i_Status_Key,@i_Env_key,@User,@Pass,@Encrypted);
    SET @InstanceID=CONVERT(int,SCOPE_IDENTITY());
   END
   ELSE SET @InstanceID=-1;
  END
  ELSE IF EXISTS (SELECT @HostID,@source,@i_instanceName,@i_DB_Type_Id,@i_Port,@i_DB_Version_Id,@i_DB_Pak_Id,@i_Status_Key,@i_Env_key EXCEPT SELECT [hostId],[Used_By],[instanceName],[DB_Type_Id],[Port],[DB_Version_Id],[DB_Pak_Id],[Status_Key],[Env_key] FROM dbo.[InstanceInfo] WHERE [instanceId]=@InstanceID)
  BEGIN
   SET @Action='Update';
   IF @Preview=0 UPDATE dbo.[InstanceInfo] SET [hostId]=@HostID,[Used_By]=@source,[instanceName]=@i_instanceName,[DB_Type_Id]=@i_DB_Type_Id,[Port]=@i_Port,[DB_Version_Id]=@i_DB_Version_Id,[DB_Pak_Id]=@i_DB_Pak_Id,[Status_Key]=@i_Status_Key,[Env_key]=@i_Env_key WHERE [instanceId]=@InstanceID;
  END
  INSERT @Results (Entity,Name,Action,RecordID) VALUES ('Instance',@i_instanceName,@Action,NULLIF(@InstanceID,-1));
  IF @Preview=1 AND @InstanceID=-1 AND (@User IS NULL OR @Pass IS NULL OR @User LIKE '%REPLACE%' OR @Pass LIKE '%REPLACE%' OR @User LIKE '%<%' OR @Pass LIKE '%<%')
   INSERT @Results (Entity,Name,Action,RecordID) VALUES ('Credentials',@i_instanceName,'NeedsInput',NULL);
  DECLARE @DatabaseJson nvarchar(max), @ApplicationJson nvarchar(max);
  DECLARE db_cursor CURSOR LOCAL FAST_FORWARD FOR SELECT value FROM OPENJSON(@Payload,'$.databases');
  OPEN db_cursor;
  FETCH NEXT FROM db_cursor INTO @DatabaseJson;
  WHILE @@FETCH_STATUS=0
  BEGIN
  IF LEN(JSON_VALUE(@DatabaseJson,'$.Dbname'))>256 THROW 51000, 'Field too long: d_Dbname', 1;
  IF LEN(JSON_VALUE(@DatabaseJson,'$.CName'))>50 THROW 51000, 'Field too long: d_CName', 1;
  DECLARE @d_Dbname varchar(256),
          @d_Env_Key int,
          @d_Status_Key int,
          @d_Archival_key int,
          @d_CName nvarchar(50);
  SELECT @d_Dbname=[Dbname], @d_Env_Key=[Env_Key], @d_Status_Key=[Status_Key], @d_Archival_key=[Archival_key], @d_CName=[CName]
  FROM OPENJSON(@DatabaseJson) WITH (
    [Dbname] varchar(256) '$.Dbname',
    [Env_Key] int '$.Env_Key',
    [Status_Key] int '$.Status_Key',
    [Archival_key] int '$.Archival_key',
    [CName] nvarchar(50) '$.CName');
  IF @d_Dbname IS NULL THROW 51000, 'Required field: d_Dbname', 1;
  IF @d_Env_Key IS NULL THROW 51000, 'Required field: d_Env_Key', 1;
  IF @d_Status_Key IS NULL THROW 51000, 'Required field: d_Status_Key', 1;
  IF @d_Env_Key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[EnvInfo] WHERE [Env_Key]=@d_Env_Key)
    THROW 51000, 'Invalid lookup: d_Env_Key', 1;
  IF @d_Status_Key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[StatusInfo] WHERE [Status_Key]=@d_Status_Key)
    THROW 51000, 'Invalid lookup: d_Status_Key', 1;
  IF @d_Archival_key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[ArchivalInfo] WHERE [archival_key]=@d_Archival_key)
    THROW 51000, 'Invalid lookup: d_Archival_key', 1;
  SET @DBID=NULL;
  SELECT @Count=COUNT(*), @DBID=MIN([dbid]) FROM dbo.[DBinfo] WITH (UPDLOCK,HOLDLOCK) WHERE instanceId=@InstanceID AND Dbname COLLATE Latin1_General_100_BIN2=@d_Dbname COLLATE Latin1_General_100_BIN2;
  IF @Count>1 THROW 51000, 'Ambiguous existing Database; resolve duplicates first.', 1;
  SET @Action='Unchanged';
  IF @Count=0
  BEGIN
   SET @Action='Create';
   IF @Preview=0
   BEGIN

    INSERT dbo.[DBinfo] ([hostid],[instanceId],[Used_By],[Dbname],[Env_Key],[Status_Key],[Archival_key],[CName]) VALUES (@HostID,@InstanceID,@source,@d_Dbname,@d_Env_Key,@d_Status_Key,@d_Archival_key,@d_CName);
    SET @DBID=CONVERT(int,SCOPE_IDENTITY());
   END
   ELSE SET @DBID=-1;
  END
  ELSE IF EXISTS (SELECT @HostID,@InstanceID,@source,@d_Dbname,@d_Env_Key,@d_Status_Key,@d_Archival_key,@d_CName EXCEPT SELECT [hostid],[instanceId],[Used_By],[Dbname],[Env_Key],[Status_Key],[Archival_key],[CName] FROM dbo.[DBinfo] WHERE [dbid]=@DBID)
  BEGIN
   SET @Action='Update';
   IF @Preview=0 UPDATE dbo.[DBinfo] SET [hostid]=@HostID,[instanceId]=@InstanceID,[Used_By]=@source,[Dbname]=@d_Dbname,[Env_Key]=@d_Env_Key,[Status_Key]=@d_Status_Key,[Archival_key]=@d_Archival_key,[CName]=@d_CName WHERE [dbid]=@DBID;
  END
  INSERT @Results (Entity,Name,Action,RecordID) VALUES ('Database',@d_Dbname,@Action,NULLIF(@DBID,-1));
  DECLARE app_cursor CURSOR LOCAL FAST_FORWARD FOR SELECT value FROM OPENJSON(@DatabaseJson,'$.applications');
  OPEN app_cursor;
  FETCH NEXT FROM app_cursor INTO @ApplicationJson;
  WHILE @@FETCH_STATUS=0
  BEGIN
  IF LEN(JSON_VALUE(@ApplicationJson,'$.AppName'))>300 THROW 51000, 'Field too long: a_AppName', 1;
  IF LEN(JSON_VALUE(@ApplicationJson,'$.BAI_Env_Key'))>25 THROW 51000, 'Field too long: a_BAI_Env_Key', 1;
  DECLARE @a_AppTypeID int,
          @a_AppName varchar(300),
          @a_Contact_Key int,
          @a_BAI_ID int,
          @a_BAI_Env_Key varchar(25);
  SELECT @a_AppTypeID=[AppTypeID], @a_AppName=[AppName], @a_Contact_Key=[Contact_Key], @a_BAI_ID=[BAI_ID], @a_BAI_Env_Key=[BAI_Env_Key]
  FROM OPENJSON(@ApplicationJson) WITH (
    [AppTypeID] int '$.AppTypeID',
    [AppName] varchar(300) '$.AppName',
    [Contact_Key] int '$.Contact_Key',
    [BAI_ID] int '$.BAI_ID',
    [BAI_Env_Key] varchar(25) '$.BAI_Env_Key');
  IF @a_AppTypeID IS NULL THROW 51000, 'Required field: a_AppTypeID', 1;
  IF @a_AppName IS NULL THROW 51000, 'Required field: a_AppName', 1;
  IF @a_Contact_Key IS NULL THROW 51000, 'Required field: a_Contact_Key', 1;
  IF @a_AppTypeID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[AppType] WHERE [AppTypeID]=@a_AppTypeID)
    THROW 51000, 'Invalid lookup: a_AppTypeID', 1;
  IF @a_Contact_Key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.[AppContact] WHERE [Contact_key]=@a_Contact_Key)
    THROW 51000, 'Invalid lookup: a_Contact_Key', 1;
  SET @AppID=NULL;
  SELECT @Count=COUNT(*), @AppID=MIN([AppId]) FROM dbo.[AppInfo] WITH (UPDLOCK,HOLDLOCK) WHERE dbid=@DBID AND AppTypeID=@a_AppTypeID AND ((@a_BAI_ID IS NOT NULL AND BAI_ID=@a_BAI_ID AND ISNULL(BAI_Env_Key,'')=ISNULL(@a_BAI_Env_Key,'')) OR (@a_BAI_ID IS NULL AND BAI_ID IS NULL AND AppName=@a_AppName));
  IF @Count>1 THROW 51000, 'Ambiguous existing Application; resolve duplicates first.', 1;
  SET @Action='Unchanged';
  IF @Count=0
  BEGIN
   SET @Action='Create';
   IF @Preview=0
   BEGIN

    INSERT dbo.[AppInfo] ([dbid],[AppTypeID],[AppName],[Contact_Key],[BAI_ID],[BAI_Env_Key]) VALUES (@DBID,@a_AppTypeID,@a_AppName,@a_Contact_Key,@a_BAI_ID,@a_BAI_Env_Key);
    SET @AppID=CONVERT(int,SCOPE_IDENTITY());
   END
   ELSE SET @AppID=-1;
  END
  ELSE IF EXISTS (SELECT @DBID,@a_AppTypeID,@a_AppName,@a_Contact_Key,@a_BAI_ID,@a_BAI_Env_Key EXCEPT SELECT [dbid],[AppTypeID],[AppName],[Contact_Key],[BAI_ID],[BAI_Env_Key] FROM dbo.[AppInfo] WHERE [AppId]=@AppID)
  BEGIN
   SET @Action='Update';
   IF @Preview=0 UPDATE dbo.[AppInfo] SET [dbid]=@DBID,[AppTypeID]=@a_AppTypeID,[AppName]=@a_AppName,[Contact_Key]=@a_Contact_Key,[BAI_ID]=@a_BAI_ID,[BAI_Env_Key]=@a_BAI_Env_Key WHERE [AppId]=@AppID;
  END
  INSERT @Results (Entity,Name,Action,RecordID) VALUES ('Application',@a_AppName,@Action,NULLIF(@AppID,-1));
   FETCH NEXT FROM app_cursor INTO @ApplicationJson;
  END
  CLOSE app_cursor;
  DEALLOCATE app_cursor;
  FETCH NEXT FROM db_cursor INTO @DatabaseJson;
  END
  CLOSE db_cursor;
  DEALLOCATE db_cursor;
  COMMIT TRANSACTION;
  SELECT Sequence,Entity,Name,Action,RecordID,@Preview AS Preview FROM @Results ORDER BY Sequence;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH
END;
GO

# DBPortal PostgreSQL registration

Standalone implementation based on your supplied dbstatus DDL and lookup screenshots.
It does not modify or depend on your Ansible build. Run from an internal management machine
that can reach PostgreSQL and DBPortal's SQL Server.

## Files

- `register_dbportal.py`: PostgreSQL collector and SQL Server procedure caller.
- `register_inventory.sql`: deployable stored procedure, defaulting to preview.
- `config.example.json`: replaceable host, application and connection configuration.
- `requirements.txt`: Python dependencies (Python 3.10+ recommended).
- `test_validation.py`: offline validation and credential-redaction checks.
- `preflight.sql`: read-only checks for duplicates, triggers, and FK state.

## Important boundaries

This is an implementation starter, locally checked but NOT executed against your databases.
Review with the DBPortal owner and validate in a nonproduction copy before production deployment.
The screenshots do not establish application-side auditing, business validation, triggers, or
all additional indexes. Direct database registration must preserve those requirements.
The code changes existing records only in the columns listed below; missing records are inserted.
It never deletes records or application associations. A wildcard application mapping is only an
example; use exact database mappings when ownership differs.

Host metadata (OS, IP, platform, cluster) is supplied in configuration; it is NOT discovered via SSH.
Confirm those facts for every host. PostgreSQL discovery reads version, configured server port,
recovery state, and database names. It does not read database contents or passwords.
Use a direct connection to the intended PostgreSQL instance, not a load balancer, PgBouncer,
or failover alias pointing to another host. The returned port is the actual PostgreSQL port.
Reachability does not prove every database is Online; status and environment are explicit inventory values.
Recovery state is reported for review, not automatically converted to DBPortal status.

## 1. SQL Server deployment

Run `preflight.sql` in SSMS in the intended dbstatus database. Review duplicates, triggers,
additional constraints and existing registration/audit procedures. Do not automatically delete duplicates.
Run `register_inventory.sql` in SSMS in a NONPRODUCTION copy first. It uses `USE [dbstatus]`;
change this if the test copy has a different name. Requirements: SQL Server 2016 SP1+ and
compatibility level 130+ for OPENJSON / CREATE OR ALTER.

Grant the registration service principal EXECUTE on the new procedure and SELECT on DBVersion
for canonical version resolution; prefer an existing approved database role. Example only:

```sql
-- Replace principal placeholder; execute using your established provisioning process.
GRANT EXECUTE ON dbo.usp_RegisterPostgresInventory TO [<REGISTRATION_DATABASE_USER>];
GRANT SELECT ON dbo.DBVersion TO [<REGISTRATION_DATABASE_USER>];
```

Same-owner static SQL normally uses ownership chaining. Confirm it in your deployment;
do not grant broad db_owner/table-write permissions to make an error disappear.
The registration procedure owns its transaction; Python opens SQL Server in autocommit mode.
No surrounding caller transaction is allowed. Existing triggers run as usual.

## 2. Python installation

Install Microsoft's ODBC Driver 18 for SQL Server on the management machine through your
approved package process (Linux also needs unixODBC). Then:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp config.example.json config.json
```

Windows PowerShell: `py -m venv .venv`, then `.\.venv\Scripts\Activate.ps1`.
Dependencies are bounded, not a reproducible lockfile; pin approved versions after testing.

## 3. Configuration and placeholders

Replace host FQDN, IPv4 address and PostgreSQL CA certificate path in config.json.
Set metadata IDs to the correct values; do not reuse example environment/OS/platform blindly.
Examples from YOUR supplied lookups:

| Meaning | Column | ID |
|---|---|---:|
| Linux | OS_Id | 2 |
| Redhat 9 | OS_Version_Id | 51 |
| Redhat 8 | OS_Version_Id | 2 |
| None/Unknown OS package | OS_Pak_Id | 3 |
| Physical / Virtual | Platform_Type | 0 / 1 |
| Postgres / Postgres Community | DB_Type_Id | 61 / 64 |
| PostgreSQL 16.15 | DB_Version_Id | 535 |
| N/A DB package | DB_Pak_Id | 3 |
| QA / Production / Development / DR / UAT / SIT | Env_key | 0 / 1 / 2 / 3 / 4 / 5 |
| Offline / Online / Retired / Temporary / Standby | Status_Key | 0 / 1 / 2 / 3 / 4 |
| Archive / No Archive | Archival_key | 1 / 2 |
| Application / Website | AppTypeID | 1 / 5 |

`DB_Version_Id` is resolved at runtime by exact canonical label in DBVersion, not hard-coded.
For example, server_version `16.15` resolves `PostgreSQL 16.15` to 535. Missing/duplicate labels
stop registration. `canonical_version_override` at the root of config is available only when
you have confirmed the correct label for a differently named edition/version.

Replace `Contact_Key` with a real INTEGER from AppContact, e.g. 123 only if 123 is the
verified correct contact. Replace AppName and optionally BAI_ID / BAI_Env_Key.
BAI_Env_Key is varchar(25), separate from the integer Env_Key; do not infer its value.
The wildcard `*` applies the same app mapping to EVERY included database. Prefer exact entries:

```json
"database_mappings": {
  "postgres": {"applications": [{"AppTypeID": 1, "AppName": "EDB Postgres", "Contact_Key": "<INTEGER>", "BAI_ID": 12508, "BAI_Env_Key": "<CONFIRMED_BAI_ENV>"}]},
  "business_db": {"CName": "<ACTUAL_CNAME>", "applications": [{"AppTypeID": 1, "AppName": "<BUSINESS_APPLICATION>", "Contact_Key": "<INTEGER>", "BAI_ID": null, "BAI_Env_Key": null}]}
}
```

Replace all angle-bracket placeholders before preview/apply. `include_templates` is true to
match your screenshots; add mappings for template0/template1 or set false if your policy excludes them.
Missing mappings fail instead of guessing. CName is limited to 50 characters by your schema.
ClusterID null explicitly clears the managed host cluster value; supply the existing correct value
when preserving a cluster association. Do not use an invented ClusterID such as 0.

## 4. Credentials

Use your approved secret store to populate environment variables; do not put secrets in config files.
The following are EXAMPLES showing placeholder names, not actual credentials:

```bash
export PG_INVENTORY_USERNAME='<POSTGRES_READ_ONLY_USERNAME>'
export PG_INVENTORY_PASSWORD='<POSTGRES_READ_ONLY_PASSWORD>'
export DBPORTAL_SQL_CONNECTION='DRIVER={ODBC Driver 18 for SQL Server};SERVER=<SQLSERVER_FQDN>,<PORT>;DATABASE=dbstatus;UID=<SQLSERVER_USERNAME>;PWD=<SQLSERVER_PASSWORD>;Encrypt=yes;TrustServerCertificate=no;'
export DBPORTAL_INSTANCE_USERNAME='<PORTAL_INSTANCE_USERNAME>'
export DBPORTAL_INSTANCE_PASSWORD='<PORTAL_INSTANCE_PASSWORD_OR_APPROVED_ENCRYPTED_VALUE>'
```

Prefer secret injection or secure prompting over entering real passwords into shell history.
On Windows set these using your approved environment/secret tooling. A supported integrated
ODBC connection string can be used instead of UID/PWD when your environment is configured for it.
ODBC special characters require correct connection-string escaping; provide a complete valid string.

Collector PostgreSQL credentials and DBPortal instance credentials are separate.
Existing InstanceInfo Username/Password/IsEncrypted are NEVER changed by this procedure.
New instances require portal credentials and honor the schema's varchar(20) limits.
The script does not implement DBPortal's encryption: supply its supported stored representation
and corresponding is_encrypted flag only after confirming the application's workflow.
Never truncate values to 20 characters or mark plaintext as encrypted.
If the owner confirms blank strings are the intended PostgreSQL policy, explicitly set
`portal_credentials.allow_empty` to true; it inserts empty strings and IsEncrypted=0 for new instances.
Otherwise leave false. Preview can report Credentials/NeedsInput for new instances;
apply rejects missing or placeholder values and rolls back the entire server registration.
Sensitive fields are redacted from successful output; driver exceptions are not echoed.
Use secure DBA diagnostics for connectivity/permission/SQL validation failures.

## 5. Run

```bash
# PostgreSQL only; no SQL Server connection and no DBPortal writes.
python register_dbportal.py --config config.json --collect-only

# SQL comparison; no INSERT/UPDATE against persistent inventory tables.
python register_dbportal.py --config config.json --preview

# Register the reviewed inventory.
python register_dbportal.py --config config.json --apply
```

Preview is the default. It acquires a transaction application lock and reads tables, so it can
briefly block other registrations. New rows have null RecordID in preview, not reserved IDs.
An apply reruns discovery and comparison; it is not a frozen approval of a previous preview.
Capture the returned JSON in your secured build/job logs for audit; the procedure does not create
a durable audit table. No credentials are included in reports. A scheduling/job system can call
this script for each configuration, but scheduling is not configured by this package.

## Matching and updates

- Host: hostname + Used_By. Confirm this key against your inventory; duplicate matches stop.
- Instance: hostId + Port. A match can update instanceName. This assumes one active instance per host/port.
- Database: instanceId + exact case-sensitive Dbname (PostgreSQL allows names differing by case).
- App association: dbid + AppTypeID + BAI_ID + BAI_Env_Key when BAI supplied;
  otherwise dbid + AppTypeID + AppName with BAI_ID null. Changing this key creates a new association;
  it does not remove the old one. Duplicate matches stop.

Updated host fields: hostname, Used_By, IPAddress, DASD, BootDASD, OS IDs, ClusterID,
status_key, Platform_Type. Updated instance fields: hostId, Used_By, instanceName, Port,
DB type/version/package IDs, status, environment. Restart/SLA/credentials are preserved.
Updated database fields: hostid, instanceId, Used_By, Dbname, environment, status, archival,
CName. createDate and SQL Server AG/tenant fields are preserved. On inserts createDate uses
its existing GETDATE() default; confirm it means portal registration time, not physical DB creation.
App fields are updated from the explicit mapping. Standby/DR policy is configured, not guessed.

The procedure acquires one global application lock, serializing its own calls. UPDLOCK/HOLDLOCK
protect its matching reads. Other UI/API writers do not participate in the application lock;
review natural-key uniqueness and concurrent portal writes with the owner. No indexes or FK
trust state are modified by deployment. Lookup IDs are checked before use. Separate DBinfo
host/instance FKs do not guarantee they agree; the procedure uses the resolved host for both.

## Acceptance checks in your test environment

1. Preview a new test server; verify lookup IDs, application mapping and proposed records in the UI.
2. Apply once; confirm HostID/instanceId/dbid/AppId relationships and portal behavior.
3. Apply unchanged input again: all inventory records should be Unchanged, without extra rows.
4. Change a test version/CName/contact: only intended managed fields should update.
5. Invalid contact/version and missing new-instance credentials must fail with no partial registration.
6. Test two simultaneous submissions and duplicate-existing-row rejection.
7. Verify template and standby handling, application audit/validation, trigger behavior and
   non-ASCII names against your varchar columns/collation. Python length checks are character-based;
   SQL Server encoding limits and application rules still apply.

Local tests: `python -m unittest -v test_validation.py`. No live SQL Server/PostgreSQL tests were
possible in the authoring environment.

## References

- https://learn.microsoft.com/en-us/sql/t-sql/functions/openjson-transact-sql
- https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql
- https://www.psycopg.org/psycopg3/docs/basic/usage.html
- https://github.com/mkleehammer/pyodbc/wiki/Calling-Stored-Procedures
